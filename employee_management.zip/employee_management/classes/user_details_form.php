<?php
namespace local_employee_management\classes;
defined('MOODLE_INTERNAL') || die;

class user_details_form extends \moodleform {
    protected $id;
   public function __construct($actionurl,$id) {
       global $CFG, $USER;

     
       $this->id=$id;
       parent::__construct($actionurl);
   }
   public function definition() {
      
       global $CFG, $DB, $output;
       $mform =& $this->_form;
       $strrequired = get_string('required');
      //get city
      $getcity=$DB->get_records('city');
      $getcityarr=array('0'=>'Select city','1'=>'Chennai','2'=>'Tenkasi','3'=>'Tirunelveli','4'=>'Theni');
    //   if(!empty($getcity)){
    //     foreach($getcity as $val){
    //         $getcityarr[$val->id]=$val->city_name;
    //     }
    //   }
       $mform->addElement('text', 'ecode', get_string('employeecode','local_employee_management'), 'size="10"');
    //    $mform->addRule('ecode', null, 'required', null, 'client');
       $mform->setType('ecode', PARAM_RAW);
       $mform->addElement('text', 'ename', get_string('employeename','local_employee_management'), 'size="50"');
       $mform->addRule('ename', null, 'required', null, 'client');
       $mform->setType('ename', PARAM_RAW);
       $mform->addElement('date_selector', 'doj', get_string('doj','local_employee_management'));
       $mform->addRule('doj', null, 'required', null, 'client');
       $mform->setType('doj', PARAM_RAW);
       $mform->addElement('text', 'address', get_string('address','local_employee_management'));
    //    $mform->addRule('address', null, 'required', null, 'client');
       $mform->setType('address', PARAM_RAW);
       $mform->addElement('select', 'city', get_string('city','local_employee_management'),$getcityarr);
       $mform->addRule('city', null, 'required', null, 'client');
       $mform->setType('city', PARAM_INT);
       $mform->addElement('text', 'zipcode', get_string('zipcode','local_employee_management'));
       $mform->addRule('zipcode', null, 'required', null, 'client');
       $mform->setType('zipcode', PARAM_RAW);
       $mform->addElement('hidden', 'id',$this->id);
       $mform->setType('id', PARAM_INT);
         // add action buttons
         $buttonarray = array();
         if(!empty($this->id)){
           $string=get_string('update','local_employee_management');
         }else{
           $string=get_string('add','local_employee_management');
         }
         $buttonarray[] = &$mform->createElement('submit', 'submitbutton',
         $string);
       
         $buttonarray[] = &$mform->createElement('cancel');
         $mform->addGroup($buttonarray, 'buttonar', '', array(' '), false);
   }
   public function validation($data, $files) {
    global $OUTPUT,$DB;
    $errors = parent::validation($data, $files);
    $error=false;
    if($data['city']==0){
        $error=true;
        if ($error) {
        $errors['city'] = 'Kindly select city';
        }
    }
    
 
    if($data['doj'] > time()){
        $error=true;
        if ($error) {
        $errors['doj'] = 'You are not allowed to choose future date';
        }
    }
    $zipcode=$data['zipcode'];

    if(!empty($zipcode)){
        if(is_numeric($zipcode)){

        }else{
            $error=true;
            if ($error) {
            $errors['zipcode'] = 'Only allow numbers';
            }
        }
    }

        $givenName=$data['ename'];
        if(!empty($givenName)){
            if(preg_match("/^([a-zA-Z' ]+)$/",$givenName)){
       
            }else{
                $error=true;
                if ($error) {
                $errors['ename'] = 'Invalid name given';
                }
                return $errors;
            }
        }
        
 
    return $errors;

}
}

