<?php
include "../../config.php";
require_once('lib.php');
if(isset($_POST['ecode'])){
    $data=new stdClass();
    $data->id=$_POST['id'];
    $data->ecode=$_POST['ecode'];
    $data->ename=$_POST['ename'];
    $data->doj=$_POST['doj'];
    $data->address=$_POST['address'];
    $data->city=$_POST['city'];
    $data->zipcode=$_POST['zipcode'];

    addnew_record($data);

}
?>