<?php
function addnew_record($data){
    global $DB,$USER,$CFG;
    if($data->id!=0){
        $updation= new stdClass;
        $updation->id=$data->id;
        $updation->employee_code=$data->ecode;
        $updation->employee_name=$data->ename;
        $updation->date_of_joining=$data->doj;
        $updation->address=$data->address;
        $updation->city=$data->city;
        $updation->zip_code=$data->zipcode;
        $updation->modified_on=time();
        $update=$DB->update_record('user_details',$updation);
        return 1;
    }else{
        $insertion= new stdClass;
        $insertion->employee_code=$data->ecode;
        $insertion->employee_name=$data->ename;
        $insertion->date_of_joining=$data->doj;
        $insertion->address=$data->address;
        $insertion->city=$data->city;
        $insertion->zip_code=$data->zipcode;
        $insertion->createdon=time();
        $insert=$DB->insert_record('user_details',$insertion);
        return 1;
    }
          
}