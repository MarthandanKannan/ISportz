<?php 
// This file is custom plugin 
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
require('../../config.php');
require('classes/user_details_form.php');
require('classes/output/index.php');
require_once('lib.php');

$linkurl = new moodle_url('/local/employee_management/addemployee.php');
require_login();
$context = context_system::instance();
$id = optional_param('id', 0, PARAM_INT);

$PAGE->set_url('/local/employee_management/addemployee.php');
$PAGE->set_context($context);
if(!has_capability('local/employee_management:formcreation', \context_user::instance($USER->id)) && !is_siteadmin()){
    redirect($CFG->wwwroot.'/my', get_string('nopermissionsdash'), 42);

}
$baseurl= new moodle_url('/local/employee_management/addemployee.php');
$PAGE->navbar->add(get_string('employeemanagement','local_employee_management'),new moodle_url('/local/employee_management/employeelist.php')); 
$PAGE->navbar->add(get_string('userdetails','local_employee_management'),$linkurl); 
$PAGE->set_title(get_string('userdetails','local_employee_management'));
$output = $PAGE->get_renderer('local_employee_management');

$PAGE->set_heading(get_string('userdetails','local_employee_management'));
if($id!=0){
    $isadding = false;
    $labelrecord = $DB->get_record_sql("SELECT id as id,employee_code as ecode,employee_name as ename, address as address,city as city,zip_code as zipcode,date_of_joining as doj FROM {user_details} WHERE id=$id");
}else{
    $isadding = true;
    $labelrecord=new stdClass;
   
}
$mform = new local_employee_management\classes\user_details_form($linkurl,$id);
$mform->set_data($labelrecord);

if ($mform->is_cancelled()) {
	
		$cancelurl=new moodle_url('/local/employee_management/employeelist.php');	
	
    redirect($cancelurl);
    die;
} else if ($data = $mform->get_data()) {
    if ($isadding) {
        $data->id = $id;
        $create=addnew_record($data);
    
            if($create==1){
                redirect(new moodle_url('/local/employee_management/employeelist.php'), get_string('insertsuceve','local_employee_management'), null, \core\output\notification::NOTIFY_SUCCESS);

            }
            }else{
                $data->id = $id;
                $create=addnew_record($data);
                if($create==1){
                    redirect(new moodle_url('/local/employee_management/employeelist.php'), get_string('updatesuc','local_employee_management'), null, \core\output\notification::NOTIFY_SUCCESS);  
                }
            }
}
echo $OUTPUT->header();
$userdetails = new local_employee_management\output\index([
    'form' => $mform->render()
]);
echo $output->render_userdetails($userdetails);
echo $OUTPUT->footer();
