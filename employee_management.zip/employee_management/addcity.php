<?php 

    
require('../../config.php');
require_once('lib.php');
require_once('form.php');
define("CERT_PER_PAGE",10);
define("CERT_MAX_PER_PAGE",200);

$delete       = optional_param('delete', 0, PARAM_INT);
$sort = optional_param('sort', '', PARAM_RAW);
$confirm      = optional_param('confirm', '', PARAM_ALPHANUM);  
$id      = optional_param('id', 0, PARAM_INT);  
$page = optional_param('page', 0, PARAM_INT);
$perpage = optional_param('perpage', CERT_PER_PAGE, PARAM_INT);
$context = context_system::instance();
require_login();
$linkurl = new moodle_url('/local/employee_management/addcity.php');
$params=array('id'=>$id, 'page' => $page, 'perpage' => $perpage);

if (CERT_PER_PAGE !== 0) {
    if (($perpage > CERT_MAX_PER_PAGE) || ($perpage <= 0)) {
        $perpage = CERT_MAX_PER_PAGE;
    }
} else {
    $perpage = '9999999';
}
$linktext = get_string('addcity','local_employee_management');
if($id!=0){
    // echo "yse";
    $isadding = false;
    $labelrecord = $DB->get_record_sql("SELECT id as id,department as dept FROM {cm_department} WHERE 
    id=$id AND institute_id=$institute_id");
    $linktext = get_string('editcity','local_employee_management');
}else{
    // echo "no";
    $isadding = true;
    $labelrecord=new stdClass;
    $linktext = get_string('addcity','local_employee_management');
}

// Print the page header.




$PAGE->set_context($context);
$PAGE->set_url($linkurl);
$PAGE->set_pagelayout('base');
$PAGE->set_title($linktext);

// Set the page heading.
$PAGE->set_heading($linktext);
$mform = new new_city($PAGE->url,$id);
$mform->set_data($labelrecord);
if ($mform->is_cancelled()) {
	
	
		$cancelurl=new moodle_url('/local/employee_management/employeelist.php');	

    redirect($cancelurl);
	
    die;
} else if ($data = $mform->get_data()) {
    if ($isadding) {
       
    $create=addnew_city($data);
    if($create==1){
        redirect(new moodle_url('/local/employee_management/employeelist.php'), get_string('cityinsertsuc','local_employee_management'), null, \core\output\notification::NOTIFY_SUCCESS);

    }
    }else{
        
        $data->id = $id;
        $create=updatenew_city($data);
        if($create==1){
            redirect(new moodle_url('/local/employee_management/employeelist.php'), get_string('updatecitysuc','local_employee_management'), null, \core\output\notification::NOTIFY_SUCCESS);  
        }
    }
}

echo $OUTPUT->header();

//delete
if ($delete and confirm_sesskey()) { 
    require_capability('moodle/user:delete', $context);
    $label = $DB->get_record('city', array('id' => $delete), '*', MUST_EXIST);
    if ($confirm != md5($delete)) {
        // echo $OUTPUT->header();
      
        echo $OUTPUT->heading(get_string('label_delete','local_employee_management'), 2, 'headingblock header');
        $optionsyes = array('delete' => $delete, 'confirm' => md5 ($delete), 'sesskey ' => sesskey());
        echo $OUTPUT->confirm(get_string('label_delete_checkfull','local_employee_management', $label->city_name),
                               new moodle_url('index.php', $optionsyes),
                               'index.php');
        echo $OUTPUT->footer();
    }else if (data_submitted()) {
        $transaction = $DB->start_delegated_transaction();

        if ( $DB->delete_records('city', array('id' => $delete)) ) {
            $transaction->allow_commit();
            redirect($baseurl, get_string('labeldeletedok','local_employee_management'), null, \core\output\notification::NOTIFY_SUCCESS);
        } else {
            $transaction->rollback();
            echo $OUTPUT->header();
            echo $OUTPUT->notification($linkurl, get_string('deletednot', 'local_employee_management', $label->city_name));
            die;
        }

        $transaction->rollback();
    }
}


$mform->display();

//tabel
$table = new html_table();
$table->head = array ();
$table->colclasses = array();

$table->attributes['class'] = 'admintable generaltable table-sm';

$table->head[] =  get_string('sno');
$table->head[] =  get_string('city', 'local_employee_management');
$table->head[] =  get_string('city_code', 'local_employee_management');
$table->head[] = get_string('action', 'local_employee_management');
$table->colclasses[] = 'centeralign';
$table->head[] = "";
$table->colclasses[] = 'centeralign';

$table->id = "labels";
$i=1;
if( $page!=0){
    
    $i=$page*10;
  
    $i++;
}
$get_label=get_alldept('','',$institute_id);

$labelcount=sizeof($get_label);
$get_label_pae=get_alldept($page , $perpage,$institute_id);

if(isset($get_label_pae)){
    foreach($get_label_pae as $gl){
        $row = array ();
        $buttons = array();
        if (has_capability('moodle/user:delete', $context)) {
        $url = new moodle_url($linkurl, array('delete'=>$gl->id, 'sesskey'=>sesskey()));
        $editurl= new moodle_url($linkurl, array('id'=>$gl->id));
        $speciurl=new moodle_url('/cm/department_creation/addspecialization.php',array('deptid'=>$gl->id));

        $surl= new moodle_url($linkurl, array('id'=>$gl->id));
        $buttons[] = html_writer::link($url, $OUTPUT->pix_icon('t/delete',get_string('delete')));
        $buttons[] = html_writer::link($editurl, $OUTPUT->pix_icon('t/editinline',get_string('edit')));
        $buttons[] = html_writer::link($speciurl, $OUTPUT->pix_icon('t/add',get_string('addspec')));	//R1024 09-10-2023

        }
        $row[] =$i;
        $row[] = $gl->department;
      
        $row[] = implode(' ', $buttons);
        $table->data[] = $row;
        $i++;
    }
}


echo html_writer::start_tag('div', array('class'=>'no-overflow'));
echo html_writer::table($table);
echo html_writer::end_tag('div');
if(sizeof($get_label_pae)<1){
     
    echo html_writer::start_span('norecords',array('data-value'=>1)) . 'No records found' . html_writer::end_span();

}
$baseurl = new moodle_url('/local/employee_management/addcity.php', array('sort' => $sort, 'page' => $page, 'perpage' => $perpage));
echo $OUTPUT->paging_bar($labelcount, $page, $perpage, $baseurl);
echo $OUTPUT->footer();
?>

<script>
     
        $(document).on('keypress', '#id_city', function (event) {
    var regex = new RegExp("^[a-zA-Z ]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) {
        event.preventDefault();
        return false;
    }
});
</script>