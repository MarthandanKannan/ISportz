<?php 
// This file is custom plugin 
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
require('../../config.php');
require('classes/user_details_form.php');
require('classes/output/index.php');
require_once('lib.php');
define("CERT_PER_PAGE",10);
define("CERT_MAX_PER_PAGE",200);
$params=array('page' => $page, 'perpage' => $perpage);
$linkurl = new moodle_url('/local/employee_management/employeelist.php',$params);
require_login();
$context = context_system::instance();
$delete       = optional_param('delete', 0, PARAM_INT);
$confirm      = optional_param('confirm', '', PARAM_ALPHANUM);  
$id      = optional_param('id', 0, PARAM_INT);  
$page = optional_param('page', 0, PARAM_INT);
$perpage = optional_param('perpage', CERT_PER_PAGE, PARAM_INT);
$sort = optional_param('sort', '', PARAM_RAW);

$PAGE->set_url('/local/employee_management/employeelist.php');
$PAGE->set_context($context);
if(!has_capability('local/employee_management:view', \context_user::instance($USER->id)) && !is_siteadmin()){
    redirect($CFG->wwwroot.'/my', get_string('nopermissionsdash'), 42);

}
$PAGE->navbar->add(get_string('employeemanagement','local_employee_management'),''); 
$PAGE->set_title(get_string('employeedetails','local_employee_management'));

$PAGE->set_heading(get_string('employeedetails','local_employee_management'));
if (CERT_PER_PAGE !== 0) {
    if (($perpage > CERT_MAX_PER_PAGE) || ($perpage <= 0)) {
        $perpage = CERT_MAX_PER_PAGE;
    }
} else {
    $perpage = '9999999';
}
$table = new html_table();
$table->head=array();
$table->colclasses = array();
//delete
if ($delete and confirm_sesskey()) { 
    // require_capability('moodle/user:delete', $context);
    $label = $DB->get_record('user_details', array('id' => $delete), '*', MUST_EXIST);

    if ($confirm != md5($delete)) {
        echo $OUTPUT->header();
      
        echo $OUTPUT->heading(get_string('deletemp','local_employee_management'), 2, 'headingblock header');
        $optionsyes = array('delete' => $delete, 'confirm' => md5 ($delete), 'sesskey ' => sesskey());
        echo $OUTPUT->confirm(get_string('cancmeet_checkfull','local_employee_management', $label->employee_name),
                               new moodle_url('employeelist.php', $optionsyes),
                               'employeelist.php');
        echo $OUTPUT->footer();
        die;
    }else if (data_submitted()) {
        $transaction = $DB->start_delegated_transaction();

        if ( $DB->delete_records('user_details', array('id'=>$delete)) ) {
            $transaction->allow_commit();
            redirect($linkurl, get_string('labeldeletedok','local_employee_management'), null, \core\output\notification::NOTIFY_SUCCESS);
        } else {
            $transaction->rollback();
            echo $OUTPUT->header();
            echo $OUTPUT->notification($linkurl, get_string('deletednot', 'local_employee_management', 'employee'));
            die;
        }

        $transaction->rollback();
    }
}
$table->attributes['class'] = 'admintable generaltable table-sm';

$table->head[] =  get_string('sno');        
$table->head[] =  get_string('employeecode','local_employee_management');
$table->head[] =  get_string('employeename','local_employee_management');
$table->head[] =  get_string('doj','local_employee_management');
$table->head[] =  get_string('address','local_employee_management');
$table->head[] =  get_string('city','local_employee_management');
$table->head[] =  get_string('zipcode','local_employee_management');
$table->head[] = get_string('action','local_employee_management');
$table->colclasses[] = 'centeralign';
$table->colclasses[] = 'centeralign';
$employeedetails = $DB->get_records_sql("SELECT * FROM {user_details}  ORDER BY employee_name ");
$labelcount=sizeof($employeedetails);
$employeedetails = $DB->get_records_sql("SELECT * FROM {user_details}  ORDER BY employee_name", array() , $page * $perpage, $perpage);
$i=1;
if( $page!=0){
    
    $i=$page*10;
  
    $i++;
}
if(!empty($employeedetails)){
foreach($employeedetails as $empl){
    $date=date('d-M-Y', $empl->date_of_joining);
    $getcity=$DB->get_record('city',array('id'=>$empl->city));
    $row = array();
    $row[]=$i;
    $row[] = $empl->employee_code;
    $row[] = $empl->employee_name;
    $row[] = $date;
    $row[] = $empl->address;
    $row[] = $getcity->city_name;
    $row[] = $empl->zip_code;
    $row[] = '<a href="addemployee.php?id='.$empl->id.'"  title="Edit" style="pointer-events:all"><i class="fa fa-edit"></i></a>
              <a href="employeelist.php?delete='.$empl->id.'&sesskey='.sesskey().'"  title="Delete" style="pointer-events:all"><i class="fa fa-trash"></i></a>';
    $table->data[] = $row;
    $i++;
}
}else{
    $row = array();
    $row[]='<td  colspan="8" style="text-align:center">'.get_string('noemplo','local_employee_management').'</td>';
    $table->data[] =  $row;
}
echo $OUTPUT->header();
$attributes = array('href' => 'addemployee.php', 
                        'aria-haspopup' => 'true','style'=>'color:white');

$output = html_writer::tag('a',get_string('addemployee','local_employee_management'), $attributes);
echo html_writer::tag('button', $output, array('class' => 'btn btn-primary'));
echo html_writer::start_tag('div', array('class'=>'no-overflow'));
echo html_writer::table($table);
echo html_writer::end_tag('div');
$baseurl = new moodle_url('/local/employee_management/employeelist.php', array('sort' => $sort, 'page' => $page, 'perpage' => $perpage));
echo $OUTPUT->paging_bar($labelcount, $page, $perpage, $baseurl);
echo $OUTPUT->footer();
