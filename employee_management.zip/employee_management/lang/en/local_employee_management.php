<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package   local_employee_management
 * @copyright 2023 
 * @author    Derick Turner
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['pluginname'] = 'Employee management';
$string['employee_management:view'] = 'view employee report';
$string['employee_management:formcreation'] = 'Employee details';
$string['employeemanagement'] = 'Employee management';
$string['userdetails'] = 'User details';
$string['employeecode'] = 'Employee code';
$string['employeename'] = 'Employee name';
$string['doj'] = 'Date of joining';
$string['address'] = 'Address';
$string['city'] = 'City';
$string['zipcode'] = 'Zip code';
$string['insertsuceve']='Inserted successfully';
$string['employeedetails']='Employee details';
$string['addemployee']='Add employee';
$string['action']='Action';
$string['noemplo']='No employee records found';
$string['add']='Add';
$string['update']='Update';
$string['updatesuc']='Updated successfully';
$string['deletemp']='Delete employee';
$string['cancmeet_checkfull']='Are you sure that you want to delete this employee - {$a} ?';
$string['labeldeletedok']='Employee deleted successfully';
$string['deletednot']='Employee not deleted';







